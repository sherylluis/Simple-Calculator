/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SG3CALC;


import java.awt.Toolkit;

import java.util.Scanner;
import javax.swing.JOptionPane;
import source.BalancedParenthensies;
import source.ReInToPre;
import javax.swing.SwingUtilities;
import javax.swing.JButton;
import javax.swing.JFrame;
/**
 *
 * @author User
 */
public class calcu extends javax.swing.JFrame {

    
    public calcu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        result = new javax.swing.JTextField();
        back = new javax.swing.JButton();
        vii = new javax.swing.JButton();
        close = new javax.swing.JButton();
        open = new javax.swing.JButton();
        multi = new javax.swing.JButton();
        viii = new javax.swing.JButton();
        viiii = new javax.swing.JButton();
        sum = new javax.swing.JButton();
        iv = new javax.swing.JButton();
        v = new javax.swing.JButton();
        vi = new javax.swing.JButton();
        min = new javax.swing.JButton();
        i = new javax.swing.JButton();
        ii = new javax.swing.JButton();
        iii = new javax.swing.JButton();
        div = new javax.swing.JButton();
        o = new javax.swing.JButton();
        dot = new javax.swing.JButton();
        equal = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        PrefixText = new javax.swing.JTextField();
        InfixText = new javax.swing.JTextField();
        PostfixText = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(28, 39, 52));

        jPanel2.setBackground(new java.awt.Color(28, 39, 52));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 255, 153)));
        jPanel2.setForeground(new java.awt.Color(51, 255, 153));

        jPanel4.setBackground(new java.awt.Color(28, 39, 52));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 255, 153)));

        result.setBackground(new java.awt.Color(28, 39, 52));
        result.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        result.setForeground(new java.awt.Color(255, 255, 255));
        result.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        result.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resultActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(result)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(result, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                .addContainerGap())
        );

        back.setBackground(new java.awt.Color(28, 39, 52));
        back.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        back.setForeground(new java.awt.Color(255, 255, 255));
        back.setText("<");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        vii.setBackground(new java.awt.Color(28, 39, 52));
        vii.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        vii.setForeground(new java.awt.Color(255, 255, 255));
        vii.setText("7");
        vii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viiActionPerformed(evt);
            }
        });

        close.setBackground(new java.awt.Color(28, 39, 52));
        close.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        close.setForeground(new java.awt.Color(255, 255, 255));
        close.setText("(");
        close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeActionPerformed(evt);
            }
        });

        open.setBackground(new java.awt.Color(28, 39, 52));
        open.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        open.setForeground(new java.awt.Color(255, 255, 255));
        open.setText(")");
        open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openActionPerformed(evt);
            }
        });

        multi.setBackground(new java.awt.Color(28, 39, 52));
        multi.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        multi.setForeground(new java.awt.Color(255, 255, 255));
        multi.setText("×");
        multi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                multiActionPerformed(evt);
            }
        });

        viii.setBackground(new java.awt.Color(28, 39, 52));
        viii.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        viii.setForeground(new java.awt.Color(255, 255, 255));
        viii.setText("8");
        viii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viiiActionPerformed(evt);
            }
        });

        viiii.setBackground(new java.awt.Color(28, 39, 52));
        viiii.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        viiii.setForeground(new java.awt.Color(255, 255, 255));
        viiii.setText("9");
        viiii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viiiiActionPerformed(evt);
            }
        });

        sum.setBackground(new java.awt.Color(28, 39, 52));
        sum.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        sum.setForeground(new java.awt.Color(255, 255, 255));
        sum.setText("+");
        sum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sumActionPerformed(evt);
            }
        });

        iv.setBackground(new java.awt.Color(28, 39, 52));
        iv.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        iv.setForeground(new java.awt.Color(255, 255, 255));
        iv.setText("4");
        iv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ivActionPerformed(evt);
            }
        });

        v.setBackground(new java.awt.Color(28, 39, 52));
        v.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        v.setForeground(new java.awt.Color(255, 255, 255));
        v.setText("5");
        v.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vActionPerformed(evt);
            }
        });

        vi.setBackground(new java.awt.Color(28, 39, 52));
        vi.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        vi.setForeground(new java.awt.Color(255, 255, 255));
        vi.setText("6");
        vi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viActionPerformed(evt);
            }
        });

        min.setBackground(new java.awt.Color(28, 39, 52));
        min.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        min.setForeground(new java.awt.Color(255, 255, 255));
        min.setText("-");
        min.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minActionPerformed(evt);
            }
        });

        i.setBackground(new java.awt.Color(28, 39, 52));
        i.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        i.setForeground(new java.awt.Color(255, 255, 255));
        i.setText("1");
        i.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iActionPerformed(evt);
            }
        });

        ii.setBackground(new java.awt.Color(28, 39, 52));
        ii.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        ii.setForeground(new java.awt.Color(255, 255, 255));
        ii.setText("2");
        ii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iiActionPerformed(evt);
            }
        });

        iii.setBackground(new java.awt.Color(28, 39, 52));
        iii.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        iii.setForeground(new java.awt.Color(255, 255, 255));
        iii.setText("3");
        iii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iiiActionPerformed(evt);
            }
        });

        div.setBackground(new java.awt.Color(28, 39, 52));
        div.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        div.setForeground(new java.awt.Color(255, 255, 255));
        div.setText("÷");
        div.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                divActionPerformed(evt);
            }
        });

        o.setBackground(new java.awt.Color(28, 39, 52));
        o.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        o.setForeground(new java.awt.Color(255, 255, 255));
        o.setText("0");
        o.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oActionPerformed(evt);
            }
        });

        dot.setBackground(new java.awt.Color(28, 39, 52));
        dot.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        dot.setForeground(new java.awt.Color(255, 255, 255));
        dot.setText(".");
        dot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dotActionPerformed(evt);
            }
        });

        equal.setBackground(new java.awt.Color(28, 39, 52));
        equal.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        equal.setForeground(new java.awt.Color(255, 255, 255));
        equal.setText("=");
        equal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                equalActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(28, 39, 52));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 255, 153)));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 346, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(204, 153, 0));

        PrefixText.setBackground(new java.awt.Color(28, 39, 52));
        PrefixText.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        PrefixText.setForeground(new java.awt.Color(255, 255, 255));
        PrefixText.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        InfixText.setBackground(new java.awt.Color(28, 39, 52));
        InfixText.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        InfixText.setForeground(new java.awt.Color(255, 255, 255));
        InfixText.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        PostfixText.setBackground(new java.awt.Color(28, 39, 52));
        PostfixText.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        PostfixText.setForeground(new java.awt.Color(255, 255, 255));
        PostfixText.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(PostfixText)
                    .addComponent(InfixText)
                    .addComponent(PrefixText))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(PrefixText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(InfixText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PostfixText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(o, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(dot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(i, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ii, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(iv, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(v, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(vii, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(viii, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(close, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(open, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                                    .addComponent(viiii, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(vi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(iii, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(multi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sum, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                                    .addComponent(min, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(div, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(equal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(close, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(open, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(multi, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(vii, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(viii, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(viiii, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sum, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(iv, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(v, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(vi, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(min, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(i, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ii, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(iii, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(div, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(o, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dot, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(equal, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel1.getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeActionPerformed
       result.setText(result.getText()+"(");
    }//GEN-LAST:event_closeActionPerformed

    private void equalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_equalActionPerformed
          // TODO add your handling code here:                                     
  
      BalancedParenthensies b = new BalancedParenthensies();
        calculate c = new calculate();
        ReInToPre pre = new ReInToPre();
        String text = result.getText();
        final JFrame parent = new JFrame();
        
        if (!"".equals(text)){
            if (b.balancedParenthensies(text) == true) {
        
                Scanner input = new Scanner(System.in);
                for (int i=0 ; i<text.length() ; i++){

                    String operator = "";
                    int count = 0;
                    while (i<text.length() && Character.isLetter(text.charAt(i))) {

                        operator += String.valueOf(text.charAt(i));

                        i++;
                        count++;
                    }

                    if (count==1){
                        i--;


                        String d = JOptionPane.showInputDialog(parent,"Inter a number as " + String.valueOf(text.charAt(i)) , null);

                        text = text.replaceAll(String.valueOf(text.charAt(i)), d);
                        System.out.println(text);
                        System.out.println(text.length());

                    }
                }
        
        

                InfixText.setText("Infix = " + text);
                result.setText(c.Evaluation(text, equal.isSelected()));
                PostfixText.setText(c.InToPoText(text));
                PrefixText.setText(pre.InToPoText(text));
                result.setText(c.Evaluation(text, equal.isSelected()));
            }
            else {
                InfixText.setText("Incorrect parentheses.");
            }
        }


    }//GEN-LAST:event_equalActionPerformed

    private void resultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resultActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_resultActionPerformed

    private void dotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dotActionPerformed
        // TODO add your handling code here:
        result.setText(result.getText()+".");
    }//GEN-LAST:event_dotActionPerformed

    private void oActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"0");
    }//GEN-LAST:event_oActionPerformed

    private void iActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"1");
    }//GEN-LAST:event_iActionPerformed

    private void iiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iiActionPerformed
         result.setText(result.getText()+"2");
    }//GEN-LAST:event_iiActionPerformed

    private void iiiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iiiActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"3");
    }//GEN-LAST:event_iiiActionPerformed

    private void divActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_divActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"÷");
    }//GEN-LAST:event_divActionPerformed

    private void minActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minActionPerformed
        result.setText(result.getText()+"-");
    }//GEN-LAST:event_minActionPerformed

    private void viActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viActionPerformed
         result.setText(result.getText()+"6");
    }//GEN-LAST:event_viActionPerformed

    private void vActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vActionPerformed
         result.setText(result.getText()+"5");
    }//GEN-LAST:event_vActionPerformed

    private void ivActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ivActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"4");
    }//GEN-LAST:event_ivActionPerformed

    private void viiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viiActionPerformed
        result.setText(result.getText()+"7");
    }//GEN-LAST:event_viiActionPerformed

    private void viiiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viiiActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"8");
    }//GEN-LAST:event_viiiActionPerformed

    private void viiiiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viiiiActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"9");
    }//GEN-LAST:event_viiiiActionPerformed

    private void sumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sumActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"+");
    }//GEN-LAST:event_sumActionPerformed

    private void multiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_multiActionPerformed
        // TODO add your handling code here:
         result.setText(result.getText()+"×");
    }//GEN-LAST:event_multiActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
         result.setText("");
        InfixText.setText("");
        PostfixText.setText("");
        PrefixText.setText("");
    }//GEN-LAST:event_backActionPerformed

    private void openActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openActionPerformed
        // TODO add your handling code here:
        result.setText(result.getText()+")");
    }//GEN-LAST:event_openActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(calcu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(calcu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(calcu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(calcu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new calcu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField InfixText;
    private javax.swing.JTextField PostfixText;
    private javax.swing.JTextField PrefixText;
    private javax.swing.JButton back;
    private javax.swing.JButton close;
    private javax.swing.JButton div;
    private javax.swing.JButton dot;
    private javax.swing.JButton equal;
    private javax.swing.JButton i;
    private javax.swing.JButton ii;
    private javax.swing.JButton iii;
    private javax.swing.JButton iv;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JButton min;
    private javax.swing.JButton multi;
    private javax.swing.JButton o;
    private javax.swing.JButton open;
    private javax.swing.JTextField result;
    private javax.swing.JButton sum;
    private javax.swing.JButton v;
    private javax.swing.JButton vi;
    private javax.swing.JButton vii;
    private javax.swing.JButton viii;
    private javax.swing.JButton viiii;
    // End of variables declaration//GEN-END:variables
}
